import { computed, inject } from '@angular/core';

// ─── Dev-time key checker ────────────────────────────────────────────────────
const EXPECTED_WELL_KEYS: (keyof IWellData)[] = [
    'WELL_MASTER',
    'RIG_ACTIVITY',
    'DRLG_OP_STATUS',
    'DRLG_FD_TDAY',
    'DRLG_FM_TOPS',
    'NEW_TARGET_DAYS',
    'NEXT_2_WELL_ACTIVITY',
    'EXAD_RCD_PREWAP',
    'EXAD_GWD_IR_CASING',
    'EXAD_GWD_IR_TOPS',
    'EXAD_GWD_IR_HYDROGEOLOGY',
    'EXAD_GWD_IR_WATER',
    'EXAD_GWD_IR_HEADER',
    'WATER_WELL_TEST_OUTCOME',
];

function logMissingWellKeys(data: IWellData, epANum: number): void {
    const missing = EXPECTED_WELL_KEYS.filter(
        (key) => data[key] === undefined || data[key] === null,
    );
    const empty = EXPECTED_WELL_KEYS.filter(
        (key) => Array.isArray(data[key]) && (data[key] as unknown[]).length === 0,
    );

    if (missing.length) {
        console.warn(
            `[WellStore] epANum=${epANum} — missing keys:`,
            missing,
        );
    }
    if (empty.length) {
        console.info(
            `[WellStore] epANum=${epANum} — present but EMPTY arrays:`,
            empty,
        );
    }
    if (!missing.length && !empty.length) {
        console.log(`[WellStore] epANum=${epANum} — all keys present ✓`);
    }
}
// ─────────────────────────────────────────────────────────────────────────────
import {
    patchState,
    signalStore,
    withComputed,
    withMethods,
    withState,
} from '@ngrx/signals';
import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { tapResponse } from '@ngrx/operators';
import { delay, map, pipe, switchMap, tap } from 'rxjs';
import { MorningReport } from '../models/well-name.model';
import { IWellData } from 'src/app/shared/models/wwell/wwell-data.model';
import { WellboreDiagramData } from '../models/wellbore-diagram.model';
import { WellDataService } from '../services/well-data.service';
import { sortCasingsByDepthDesc } from 'src/app/shared/utils/wellbore-math.util';
import { MoriningReportService } from '../services/morning-report-service';
import { WellName } from '../models/well-name.model';
import { IFormationTops } from 'src/app/shared/models/wwell/formation-tops.model';
import { WellLogsIndicators } from 'src/app/shared/models/wwell/well-logs-indicators.model';
import { IHeaderIR } from 'src/app/shared/models/wwell/header-ir.model';
import { LoaderService } from 'src/app/shared/components/global-loader/loader.service';

// Minimum ms the loader stays visible — prevents flash-of-loader on fast responses
const MIN_LOADER_DELAY = 800;

export interface MiscWellData {
    wellName: string;
    wellType: string;
    targetedAquifer: string;
    currentStatus: string;
    daysSinceSpud: number;
    targetDays: number;
    biNum: string;
    waterWell: string;
    footage: number;
    previousWell: string;
    currentDepth: number;
    nextWell: string;
    feetDrilledToday: number;
    targetDesc: string;
    supportingWell: string;
}

export interface PickedFormationTops {
    formation: string;
    depth: number;
    remarks: string;
}

export interface OffsetWaterWells {
    wellName: string;
    aquifer: string;
    tds: number;
    rpm: number;
    h2s: number;
    distance: number;
    productivity: number;
    rate: number;
}

const PAGE_SIZE = 5;

interface WellState {
    readonly wellNames: WellName[];
    readonly selectedEpANum: number | null;
    readonly wellDetails: IWellData | null;
    readonly loading: boolean;
    readonly error: string | null;
    readonly animationTrigger: number;
    readonly wellNamesPage: number;
}

const initialState: WellState = {
    wellNames: [],
    selectedEpANum: null,
    wellDetails: null,
    loading: false,
    error: null,
    animationTrigger: 0,
    wellNamesPage: 0,
};

const FALLBACK_STR = 'N/A';

function mapToMiscWellData(d: IWellData | null): MiscWellData | null {
    if (!d) return null;
    const rigActivity = d.RIG_ACTIVITY?.[0];
    const drlgOpStatus = d.DRLG_OP_STATUS?.[0];

    return {
        wellName: rigActivity?.wellName ?? d.WELL_MASTER?.[0]?.well ?? FALLBACK_STR,
        targetDesc: rigActivity?.welltype ?? rigActivity?.drlgPlanWellDesc ?? FALLBACK_STR,
        targetedAquifer: d.EXAD_GWD_IR_HYDROGEOLOGY?.[0]?.estTargetAquifier ?? FALLBACK_STR,
        currentStatus: drlgOpStatus?.nxt24HrPlanRmk ?? drlgOpStatus?.wOpRmk ?? FALLBACK_STR,
        daysSinceSpud: drlgOpStatus?.spuddays ?? 0,
        targetDays: d.NEW_TARGET_DAYS?.[0]?.targetDays ?? rigActivity?.wDrlgTrgtDay ?? 0,
        biNum: rigActivity?.biNum ?? FALLBACK_STR,
        supportingWell: rigActivity?.waterWell ?? FALLBACK_STR,
        feetDrilledToday: d.DRLG_FD_TDAY?.[0]?.footage ?? drlgOpStatus?.footage ?? 0,
        previousWell: FALLBACK_STR,
        currentDepth: drlgOpStatus?.wPrsntDpth ?? 0,
        nextWell: d.NEXT_2_WELL_ACTIVITY?.[0]?.nextWellActivity ?? FALLBACK_STR,
        wellType: '',
        waterWell: '',
        footage: 0,
    };
}

export const WellStore = signalStore(
    { providedIn: 'root' },
    withState<WellState>(initialState),

    withComputed(({ wellDetails, wellNames, wellNamesPage }) => ({

        uniqueWellNames: computed(() => {
            const seen = new Set<string>();
            return wellNames().filter((w) => {
                if (seen.has(w.wellName)) return false;
                seen.add(w.wellName);
                return true;
            });
        }),

        isLoaded: computed(() => wellDetails() !== null),

        totalDepth: computed(() => {
            const d = wellDetails();
            if (!d) return 0;
            return d.EXAD_RCD_PREWAP?.[0]?.estTargetDepth ?? 0;
        }),

        totalPages: computed(() => {
            const seen = new Set<string>();
            const unique = wellNames().filter((w) => {
                if (seen.has(w.wellName)) return false;
                seen.add(w.wellName);
                return true;
            });
            return Math.ceil(unique.length / PAGE_SIZE);
        }),

        pagedWellNames: computed(() => {
            const seen = new Set<string>();
            const unique = wellNames().filter((w) => {
                if (seen.has(w.wellName)) return false;
                seen.add(w.wellName);
                return true;
            });
            const start = wellNamesPage() * PAGE_SIZE;
            return unique.slice(start, start + PAGE_SIZE);
        }),

        hasPrevPage: computed(() => wellNamesPage() > 0),

        hasNextPage: computed(() => {
            const seen = new Set<string>();
            const unique = wellNames().filter((w) => {
                if (seen.has(w.wellName)) return false;
                seen.add(w.wellName);
                return true;
            });
            return (wellNamesPage() + 1) * PAGE_SIZE < unique.length;
        }),

        diagramData: computed((): WellboreDiagramData | null => {
            const d = wellDetails();
            if (!d) return null;
            const totalDepth   = d.EXAD_RCD_PREWAP?.[0]?.estTargetDepth ?? 0;
            const rawDepth     = d.DRLG_OP_STATUS?.[0]?.wPrsntDpth ?? 0;
            const currentDepth = rawDepth > 0 && rawDepth <= totalDepth ? rawDepth : totalDepth;
            return {
                wellName: d.WELL_MASTER?.[0]?.well ?? '',
                totalDepth,
                casings: sortCasingsByDepthDesc(d.EXAD_GWD_IR_CASING ?? []),
                geologicTops: [...(d.EXAD_GWD_IR_TOPS ?? [])].sort(
                    (a, b) => a.planTvdDepth - b.planTvdDepth,
                ),
                hydrogeology: d.EXAD_GWD_IR_HYDROGEOLOGY?.[0] ?? null,
                prewap: d.EXAD_RCD_PREWAP?.[0] ?? null,
                rigActivity: d.RIG_ACTIVITY?.[0] ?? null,
                currentDepth,
            };
        }),

        miscWellData: computed(() => mapToMiscWellData(wellDetails())),

        pickedFormations: computed((): PickedFormationTops[] => {
            return (wellDetails()?.DRLG_FM_TOPS ?? []).map((fm: IFormationTops) => ({
                formation: fm.stLongCd ?? '',
                depth: fm.wStDmrkDpth ?? 0,
                remarks: fm.wStDmrkRmk ?? ''
            }));
        }),

        offsetWells: computed((): OffsetWaterWells[] => {
            const d = wellDetails();
            if (!d) return [];
            const offsetData = d.EXAD_GWD_IR_WATER ?? [];
            const testOutcomes = d.WATER_WELL_TEST_OUTCOME ?? [];
            return offsetData.map((ow) => {
                const test = testOutcomes.find(t => t.wellName === ow.offsetWaterWell);
                return {
                    wellName: ow.offsetWaterWell,
                    aquifer: ow.aquifer || test?.aquifer || 'WASI',
                    tds: test?.tds ?? 0,
                    rpm: ow?.rpm ?? 0,
                    h2s: ow.h2s,
                    distance: ow.distance ?? 0,
                    productivity: d.EXAD_GWD_IR_HYDROGEOLOGY?.[0]?.estProductivity ?? 2.1,
                    rate: test?.flowRate ?? ow.flowRate ?? 930
                };
            });
        }),

        wellsLogsIndicators: computed<WellLogsIndicators | null>(() => {
            const d = wellDetails();
            if (!d) return null;
            const header: IHeaderIR | undefined = d.EXAD_GWD_IR_HEADER?.[0];
            return {
                rcc:     !!(header?.dtRemarks?.trim()),
                mud:     !!(header?.mudRemarks?.trim()),
                logging: !!(header?.loggingRemarks?.trim()),
            };
        }),

    })),

    withMethods((
        store,
        wellDataService = inject(WellDataService),
        morningReportService = inject(MoriningReportService),
        loaderService = inject(LoaderService),
    ) => {
        const selectWell = rxMethod<number>(
            pipe(
                tap((epANum) => {
                    loaderService.show();            // ← show loader on well select
                    patchState(store, {
                        selectedEpANum: epANum,
                        loading: true,
                        error: null,
                    });
                }),
                switchMap((epANum) =>
                    wellDataService.getWellDetails(epANum).pipe(
                        delay(MIN_LOADER_DELAY),     // ← minimum visible duration
                        tapResponse({
                            next: (wellDetails) => {
                                logMissingWellKeys(wellDetails, store.selectedEpANum()!);
                                patchState(store, {
                                    wellDetails,
                                    loading: false,
                                    animationTrigger: store.animationTrigger() + 1,
                                });
                                loaderService.hide();
                            },
                            error: (err: Error) => {
                                patchState(store, {
                                    error: err.message ?? 'Failed to load well details',
                                    loading: false,
                                });
                                loaderService.hide();
                            },
                        }),
                    ),
                ),
            ),
        );

        const loadWellNames = rxMethod<void>(
            pipe(
                tap(() => {
                    loaderService.show();            // ← show on initial project load
                    patchState(store, { loading: true, error: null });
                }),
                switchMap(() =>
                    morningReportService.getMorningReport().pipe(
                        delay(MIN_LOADER_DELAY),     // ← minimum visible duration
                        map((reports: MorningReport[]) =>
                            reports.map((report) => ({
                                wellName: report.wGnrName,
                                epANum: Number(report.epANum)
                            }))
                        ),
                        tapResponse({
                            next: (wellNames) => {
                                patchState(store, { wellNames, loading: false });
                                loaderService.hide(); // ← hide after names load
                                if (wellNames.length > 0 && !store.selectedEpANum()) {
                                    selectWell(wellNames[0].epANum);
                                }
                            },
                            error: (err: Error) => {
                                patchState(store, {
                                    error: err.message ?? 'Failed to load well names',
                                    loading: false,
                                });
                                loaderService.hide();
                            },
                        }),
                    ),
                ),
            ),
        );

        return {
            selectWell,
            loadWellNames,
            nextPage(): void {
                const nextPageIndex = store.wellNamesPage() + 1;
                patchState(store, { wellNamesPage: nextPageIndex });
                const seen = new Set<string>();
                const unique = store.wellNames().filter((w) => {
                    if (seen.has(w.wellName)) return false;
                    seen.add(w.wellName);
                    return true;
                });
                const firstOnPage = unique[nextPageIndex * PAGE_SIZE];
                if (firstOnPage) selectWell(firstOnPage.epANum);
            },
            prevPage(): void {
                const prevPageIndex = Math.max(0, store.wellNamesPage() - 1);
                patchState(store, { wellNamesPage: prevPageIndex });
                const seen = new Set<string>();
                const unique = store.wellNames().filter((w) => {
                    if (seen.has(w.wellName)) return false;
                    seen.add(w.wellName);
                    return true;
                });
                const firstOnPage = unique[prevPageIndex * PAGE_SIZE];
                if (firstOnPage) selectWell(firstOnPage.epANum);
            },
        };
    }),
);