import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  effect,
  input,
} from '@angular/core';
import { select, Selection } from 'd3-selection';
import { easeCubicInOut } from 'd3-ease';
import 'd3-transition';

import { ANIM, ANIM_MODE, computeOverlayDelay, DIAGRAM_LAYOUT, WellboreDiagramData } from '../../../../models/well-design/wellbore-diagram.model';
import { ICasingIR } from '../../../../shared/models/wwell/casing-ir.model';
import { ITopsIR } from '../../../../shared/models/wwell/top-sir.model';
import {
  buildArrowHeadRight,
  buildCasingPath,
  buildDepthArrow,
  buildOpenHolePath,
  buildGravelPackUPath,
  buildScreenHanger,
  casingGradientId,
  computeCasingHalfWidth,
  createDepthScale,
  formatDepth,
  openHoleHalfWidth,
  sortCasingsByDepthDesc
} from '../../../../utils/wellbore-math.util';

type SvgSel = Selection<SVGSVGElement, unknown, null, undefined>;
type GSel = Selection<SVGGElement, unknown, null, undefined>;
type DefsSel = Selection<SVGDefsElement, unknown, null, undefined>;

@Component({
  selector: 'app-well-bore-view',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './wellbore-view.component.html',
  styleUrl: './wellbore-view.component.scss',
})
export class WellBoreViewComponent implements OnInit {
  readonly diagramData = input.required<WellboreDiagramData | null>();
  readonly animTrigger = input.required<number>();

  @ViewChild('wellboreSvg', { static: true })
  private readonly svgRef!: ElementRef<SVGSVGElement>;

  private readonly layout = DIAGRAM_LAYOUT;
  private rootG!: GSel;
  private defsEl!: DefsSel;
  private ready = false;

  constructor() {
    effect(() => {
      const trigger = this.animTrigger();
      const data = this.diagramData();
      if (data && (this.ready || trigger > 0)) {
        this.redraw(data);
      }
    });
  }

  ngOnInit(): void {
    this.bootstrapSvg();
    this.ready = true;
    const data = this.diagramData();
    if (data) this.redraw(data);
  }

  private bootstrapSvg(): void {
    const { wellboreViewWidth, svgHeight, marginTop } = this.layout;
    const svg = select(this.svgRef.nativeElement) as SvgSel;

    svg.attr('width', '100%')
      .attr('height', '100%')
      .attr('viewBox', `0 0 ${wellboreViewWidth} ${svgHeight}`)
      .attr('preserveAspectRatio', 'xMidYMin meet');

    this.defsEl = svg.append('defs') as DefsSel;
    this.addStaticDefs(this.defsEl);

    this.rootG = svg.append('g')
      .attr('class', 'wellbore-root')
      .attr('transform', `translate(0,${marginTop})`) as GSel;
  }

  private redraw(data: WellboreDiagramData): void {
    this.rootG.selectAll('*').remove();
    this.defsEl.selectAll('.dyn-clip').remove();

    const { drawingHeight, geoLineX, casingCenterX } = this.layout;
    const scale = createDepthScale(data.totalDepth, drawingHeight);
    const targetAquifer = data.hydrogeology?.estTargetAquifier ?? null;

    // ── Build a strict sequential timeline ─────────────────────────────────
    // Each phase starts only after the previous phase fully completes.
    // t = absolute ms from t=0 when redraw() fires.

    const structuralCasings = data.casings.filter(
      (c: ICasingIR) => c.csgType !== 'Liner' && c.csgType !== 'Gravel Pack'
    );

    // Phase 1: casings drill down (outer → inner)
    const t_casingsStart = 0;
    const t_casingsDone = computeOverlayDelay(structuralCasings.length); // last casing finishes

    // Phase 2: open hole clip reveals after all casings done
    const t_ohStart = t_casingsDone + ANIM.SEQ_GAP;
    const t_ohDone = t_ohStart + ANIM.OH_DURATION;

    // Phase 3: gravel pack after open hole is visible
    const t_gravelStart = t_ohDone + ANIM.SEQ_GAP;
    const t_gravelDone = t_gravelStart + ANIM.GRAVEL_DURATION;

    // Phase 4: hanger appears after gravel
    const t_hangerStart = t_gravelDone + ANIM.SEQ_GAP;
    const t_hangerDone = t_hangerStart + ANIM.HANGER_DURATION;

    // Phase 5: drill arrow travels down simultaneously with casings
    // Duration = total casing animation time so arrow reaches bottom when last casing finishes
    const t_drillStart = 0;
    const t_drillDone = t_casingsDone;

    // Phase 6: labels + water level stagger in
    const t_labelsStart = t_casingsDone + ANIM.SEQ_GAP;  // casing labels alongside OH
    const t_ohLabelStart = t_ohDone + ANIM.SEQ_GAP;
    const t_waterStart = t_ohLabelStart + ANIM.OVERLAY_FADE + ANIM.SEQ_GAP;
    const t_notDrilledStart = t_drillDone + ANIM.SEQ_GAP;
    const t_tdLabelStart = t_notDrilledStart + ANIM.OVERLAY_FADE + ANIM.SEQ_GAP;

    // ── Draw (SVG paint order: earlier = behind) ───────────────────────────
    // Phase 0: static chrome + geo tops — immediate
    this.drawStaticChrome(geoLineX, casingCenterX);
    this.drawGeologicTops(data.geologicTops, geoLineX, scale, targetAquifer);

    // Open hole paths drawn BEFORE casings so casing walls paint over them
    this.drawOpenHoleAndScreen(data, casingCenterX, scale, t_ohStart, t_ohDone, t_ohLabelStart);
    this.drawScreenHanger(data, casingCenterX, scale, t_hangerStart);

    // Casings on top of open hole
    this.drawCasings(data.casings, casingCenterX, scale, t_casingsStart, t_gravelStart, t_gravelDone);

    // Labels after casings done
    this.drawCasingLabels(data.casings, casingCenterX, scale, t_labelsStart);
    this.drawWaterLevel(data, casingCenterX, scale, t_waterStart);
    this.drawDrillArrow(data, scale, t_drillStart, t_casingsDone);
    this.drawNotDrilledZone(data, casingCenterX, scale, t_notDrilledStart);
    this.drawTotalDepthLabel(data.totalDepth, casingCenterX, drawingHeight, t_tdLabelStart);
  }

  private addStaticDefs(defs: DefsSel): void {
    // Dark-theme casing gradients — metallic steel look on dark canvas
    this.addLinearGradient(defs, 'mainGradient', [
      { offset: '0%', color: '#2d3748' },
      { offset: '40%', color: '#c9d1d9' },
      { offset: '60%', color: '#e6edf3' },
      { offset: '100%', color: '#2d3748' },
    ]);
    this.addLinearGradient(defs, 'conductorGradient', [
      { offset: '0%', color: '#1a3a2a' },
      { offset: '45%', color: '#3fb950' },
      { offset: '55%', color: '#56d364' },
      { offset: '100%', color: '#1a3a2a' },
    ]);
    this.addLinearGradient(defs, 'linerGradient', [
      { offset: '0%', color: '#2d3748' },
      { offset: '40%', color: '#8b949e' },
      { offset: '60%', color: '#c9d1d9' },
      { offset: '100%', color: '#2d3748' },
    ]);

    const grid = defs.append('pattern')
      .attr('id', 'gridPattern')
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 6).attr('height', 6);
    grid.append('path')
      .attr('d', 'M6,-4 L6,6 L-4,6')
      .attr('stroke', '#58a6ff')
      .attr('stroke-width', 1)
      .attr('opacity', '0.35')
      .attr('fill', 'none');

    const gravelPattern = defs.append('pattern')
      .attr('id', 'gravelpattern')
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 8)
      .attr('height', 4);

    gravelPattern.append('rect')
      .attr('x', 0).attr('y', 0)
      .attr('width', 4).attr('height', 2)
      .attr('fill', '#1a1a1a').attr('opacity', '0.85');

    gravelPattern.append('rect')
      .attr('x', 4).attr('y', 2)
      .attr('width', 4).attr('height', 2)
      .attr('fill', '#1a1a1a').attr('opacity', '0.85');

    const dashedPattern = defs.append('pattern')
      .attr('id', 'dashed')
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 5).attr('height', 5);

    dashedPattern.append('image')
      .attr('href', "data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHdpZHRoPScxMCcgaGVpZ2h0PScxMCc+CiAgPHJlY3Qgd2lkdGg9JzEwJyBoZWlnaHQ9JzEwJyBmaWxsPSd3aGl0ZScgLz4KICA8Y2lyY2xlIGN4PScyLjUnIGN5PScyLjUnIHI9JzIuNScgZmlsbD0nYmxhY2snLz4KPC9zdmc+");

    const addMarker = (id: string, fill: string): void => {
      defs.append('marker')
        .attr('id', id)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 5).attr('refY', 0)
        .attr('markerWidth', 4).attr('markerHeight', 4)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', fill);
    };
    addMarker('arrowBlack', '#000');
    addMarker('arrowBlue', '#3CC3FF');
  }

  private addLinearGradient(
    defs: DefsSel,
    id: string,
    stops: { offset: string; color: string }[],
  ): void {
    const g = defs.append('linearGradient').attr('id', id);
    stops.forEach(({ offset, color }) =>
      g.append('stop').attr('offset', offset).attr('stop-color', color),
    );
  }

  private getCasingTier(csg: ICasingIR, casings: ICasingIR[]): number {
    const structuralCasings = casings.filter(c => c.csgType !== 'Gravel Pack');
    const idx = structuralCasings.indexOf(csg);
    return idx === -1 ? 0 : idx;
  }

  private drawStaticChrome(geoLineX: number, centerX: number): void {
    this.rootG.append('line')
      .attr('class', 'ground-line')
      .attr('x1', 0).attr('x2', centerX + 320)
      .attr('y1', -3).attr('y2', -3);

    this.rootG.append('text')
      .attr('class', 'ground-label')
      .attr('x', centerX).attr('y', -12)
      .attr('text-anchor', 'middle')
      .text('Ground Level');

    this.rootG.append('line')
      .attr('class', 'geo-axis')
      .attr('x1', geoLineX).attr('x2', geoLineX)
      .attr('y1', 0).attr('y2', this.layout.drawingHeight);

    this.rootG.append('text')
      .attr('class', 'column-label')
      .attr('x', geoLineX).attr('y', -30)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .call((t) => {
        t.append('tspan').attr('x', geoLineX).attr('dy', 0).text('Geologic');
        t.append('tspan').attr('x', geoLineX).attr('dy', 12).text('Horizons (ft bgl)');
      });
  }

  private drawGeologicTops(
    tops: ITopsIR[],
    geoLineX: number,
    scale: ReturnType<typeof createDepthScale>,
    targetAquifer: string | null,
  ): void {
    const sorted = [...tops].sort((a, b) => a.planTvdDepth - b.planTvdDepth);
    sorted.forEach((top, idx) => {
      const isTarget = !!targetAquifer && top.stLongCd === targetAquifer;

      const yPx = scale(top.planTvdDepth);
      const g = this.rootG.append('g')
        .attr('class', isTarget ? 'geo-top geo-top--target' : 'geo-top')
        .attr('transform', `translate(0,${yPx})`)
        .style('opacity', 0);

      if (isTarget) {
        g.append('rect')
          .attr('class', 'geo-target-band')
          .attr('x', geoLineX - 75)
          .attr('width', 150)
          .attr('height', 25)
          .attr('y', -14)
          .attr('rx', 3);
      }

      g.append('line')
        //.attr('class', isTarget ? 'geo-tick geo-tick--target' : 'geo-tick')
        .attr('class', 'geo-tick')
        .attr('x1', geoLineX - 14).attr('x2', geoLineX + 14)
        .attr('y1', 0).attr('y2', 0);

      g.append('text')
        //.attr('class', isTarget ? 'geo-depth geo-depth--target' : 'geo-depth')
        .attr('class', 'geo-depth')
        .attr('x', geoLineX - 17)
        .attr('dy', '0.35em')
        .text(top.planTvdDepth.toLocaleString());

      g.append('text')
        //.attr('class', isTarget ? 'geo-code geo-code--target' : 'geo-code')
        .attr('class', 'geo-code')
        .attr('x', geoLineX + 18)
        .attr('dy', '0.35em')
        .text(top.stLongCd);

      g.transition()
        .delay(ANIM.GEO_DELAY + idx * ANIM.GEO_STAGGER)
        .duration(220)
        .style('opacity', 1);
    });
  }

  private drawCasings(
    casings: ICasingIR[],
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    casingsStart: number,
    gravelStart: number,
    gravelDone: number,
  ): void {
    const { baseHalfWidth, halfWidthIncrement, shoeCurveOffset } = this.layout;

    casings.forEach((csg, i) => {
      if (csg.csgType === 'Liner') return;

      const tier = this.getCasingTier(csg, casings);
      const hw = computeCasingHalfWidth(tier, baseHalfWidth, halfWidthIncrement);
      const bottomPx = scale(csg.csgDepth);
      const clipId = `dyn-casing-clip-${i}`;

      const animOrder = casings.length - 1 - i;
      const delay = animOrder * ANIM.CASING_STAGGER;

      const clipRadius = csg.csgType === 'Gravel Pack'
        ? (computeCasingHalfWidth(0, baseHalfWidth, halfWidthIncrement) - 10) + 20  // screenHW + padding
        : openHoleHalfWidth(hw) + 20;

      const clipRect = this.defsEl
        .append('clipPath')
        .attr('class', 'dyn-clip')
        .attr('id', clipId)
        .append('rect')
        .attr('x', centerX - clipRadius - 15)
        .attr('y', -5)
        .attr('width', clipRadius * 2 + 30)
        .attr('height', 0);

      if (csg.csgType === 'Gravel Pack') {

        const deepestSolid = casings.find(c => c.csgType !== 'Liner' && c.csgType !== 'Gravel Pack');
        const startDepthPx = deepestSolid ? scale(deepestSolid.csgDepth) : 0;

        // Gravel bottom = actual csgDepth from data, clamped to totalDepth scale
        const gravelBottomPx = scale(csg.csgDepth);

        const innerHW = computeCasingHalfWidth(0, this.layout.baseHalfWidth, this.layout.halfWidthIncrement);
        const screenHW = innerHW - 10;
        const annulusWidth = 10;                    // thin band matching screen tube thickness
        const annulusCenter = screenHW - (annulusWidth / 2);  // hugs the inner wall of screen

        this.rootG.append('path')
          .attr('class', 'gravelHole')
          .attr('d', buildGravelPackUPath(centerX, annulusCenter, startDepthPx, gravelBottomPx))
          .attr('stroke', 'url(#gravelpattern)')
          .attr('stroke-width', String(annulusWidth))
          .style('fill', 'none')
          .attr('clip-path', `url(#${clipId})`);
        // Gravel clip uses its own sequential timing (after open hole)
        clipRect.transition()
          .delay(gravelStart)
          .duration(ANIM.GRAVEL_DURATION)
          .ease(easeCubicInOut)
          .attr('height', gravelBottomPx + 20);
        return;  // skip the generic clipRect transition below
      } else {
        this.rootG.append('path')
          .attr('class', 'casing')
          .attr('d', buildCasingPath(centerX, hw, 0, bottomPx, shoeCurveOffset))
          .attr('clip-path', `url(#${clipId})`)
          .attr('fill', `url(#${casingGradientId(csg.csgType)})`)
          .style('opacity', csg.csgType === 'Conductor' ? 0.92 : 0.65);
      }

      clipRect.transition()
        .delay(casingsStart + delay)
        .duration(ANIM.CASING_DURATION)
        .ease(easeCubicInOut)
        .attr('height', bottomPx + shoeCurveOffset + 20);
    });
  }

  private drawCasingLabels(
    casings: ICasingIR[],
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    labelsStart: number,
  ): void {
    const { baseHalfWidth, halfWidthIncrement } = this.layout;
    const allDone = labelsStart;

    casings.forEach((csg, i) => {
      if (csg.csgType === 'Liner') return;

      const tier = this.getCasingTier(csg, casings);
      const hw = computeCasingHalfWidth(tier, baseHalfWidth, halfWidthIncrement);
      const shoePx = scale(csg.csgDepth);

      // For Gravel Pack label, point to the actual csgDepth from data
      let labelYPx = shoePx;
      if (csg.csgType === 'Gravel Pack') {
        labelYPx = scale(csg.csgDepth);
      }

      const rEdge = csg.csgType === 'Gravel Pack'
        ? centerX + (computeCasingHalfWidth(0, baseHalfWidth, halfWidthIncrement) - 10)
        : centerX + hw;

      const lEnd = rEdge + 22;
      const labelX = lEnd + 8;

      const lg = this.rootG.append('g')
        .attr('class', 'casing-label')
        .style('opacity', 0);

      lg.append('line')
        .attr('class', 'casing-label__line')
        .attr('x1', rEdge).attr('x2', lEnd)
        .attr('y1', labelYPx).attr('y2', labelYPx);

      lg.append('path')
        .attr('class', 'casing-label__arrow')
        .attr('d', buildArrowHeadRight(lEnd, labelYPx, 6));

      if (csg.csgType === 'Gravel Pack') {
        lg.append('text')
          .attr('class', 'casing-label__primary')
          .attr('x', labelX).attr('y', labelYPx + 4)
          .text(csg.csgRemarks || 'Gravel Pack');
      } else {
        lg.append('text')
          .attr('class', 'casing-label__primary')
          .attr('x', labelX).attr('y', shoePx + 4)
          .text(`${csg.csgSize}" ${csg.csgType} @ ${csg.csgDepth.toLocaleString()}`);

        if (csg.csgRemarks) {
          lg.append('text')
            .attr('class', 'casing-label__secondary')
            .attr('x', labelX).attr('y', shoePx + 17)
            .text(`(${csg.csgRemarks})`);
        }

        this.rootG.append('text')
          .attr('class', 'casing-size-inner')
          .attr('x', centerX).attr('y', shoePx - 9)
          .attr('text-anchor', 'middle')
          .style('opacity', 0)
          .text(`${csg.csgSize}"`)
          .transition().delay(allDone).duration(250).style('opacity', 1);
      }

      lg.transition()
        .delay(allDone)
        .duration(300)
        .ease(easeCubicInOut)
        .style('opacity', 1);
    });
  }

  private drawWaterLevel(
    data: WellboreDiagramData,
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    waterStart: number,
  ): void {
    if (!data.hydrogeology) return;
    const { baseHalfWidth, halfWidthIncrement } = this.layout;
    const wPx = scale(data.hydrogeology.estStaticWaterLevel);

    const widestCsg = data.casings[data.casings.length - 1];
    const tier = widestCsg ? this.getCasingTier(widestCsg, data.casings) : 0;
    const innerHW = computeCasingHalfWidth(tier, baseHalfWidth, halfWidthIncrement);

    const lR = centerX + innerHW + 10;
    const lL = centerX - innerHW - 10;
    const label = data.hydrogeology.flowType === 'Y'
      ? 'Flowing (SIWHP: 50 PSI)'
      : `Static WL: ${data.hydrogeology.estStaticWaterLevel.toLocaleString()} ft`;

    const wg = this.rootG.append('g').attr('class', 'water-level').style('opacity', 0);

    wg.append('line')
      .attr('class', 'water-line')
      .attr('x1', lL).attr('x2', lR)
      .attr('y1', wPx).attr('y2', wPx);

    wg.append('path')
      .attr('class', 'water-arrow')
      .attr('d', `M${lL} ${wPx - 5} L${lL - 10} ${wPx} L${lL} ${wPx + 5} Z`);

    wg.append('text')
      .attr('class', 'water-label')
      .attr('x', lR - 350).attr('y', wPx + 4)
      .text(label);

    wg.transition().delay(waterStart).duration(ANIM.OVERLAY_FADE).ease(easeCubicInOut).style('opacity', 1);
  }

  private drawOpenHoleAndScreen(
    data: WellboreDiagramData,
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    ohStart: number,
    ohDone: number,
    ohLabelStart: number,
  ): void {
    if (!data.casings.length) return;

    const { baseHalfWidth, halfWidthIncrement } = this.layout;
    const innerHW = computeCasingHalfWidth(0, baseHalfWidth, halfWidthIncrement);
    const ohHW = openHoleHalfWidth(innerHW);
    const layout = this.layout;
    const screenHW = innerHW - 10;

    const deepestSolid = data.casings.find((c: ICasingIR) => c.csgType !== 'Liner' && c.csgType !== 'Gravel Pack') || data.casings[0];
    const liner = data.casings.find((c: ICasingIR) => c.csgType === 'Liner');

    const shoePx = scale(deepestSolid.csgDepth);
    const tdPx = scale(data.totalDepth);
    const ratHolePx = 15;
    const screenBottomPx = liner ? scale(liner.csgDepth) : (tdPx - ratHolePx);

    const clipId = 'dyn-oh-clip';
    const clipRect = this.defsEl
      .append('clipPath').attr('class', 'dyn-clip').attr('id', clipId)
      .append('rect')
      .attr('x', centerX - ohHW - 15).attr('y', shoePx - 5)
      .attr('width', ohHW * 2 + 30).attr('height', 0);

    this.rootG.append('path')
      .attr('class', 'open-hole')
      .attr('d', buildOpenHolePath(centerX, ohHW, shoePx, tdPx))
      .attr('clip-path', `url(#${clipId})`);

    this.rootG.append('path')
      .attr('class', 'liner-screen')
      .attr('d', buildOpenHolePath(centerX, screenHW, shoePx, screenBottomPx))
      .attr('clip-path', `url(#${clipId})`);

    // Hanger drawn separately in drawScreenHanger() after drawCasings() so it renders on top

    const ohLY = shoePx + (tdPx - shoePx) * 0.2;
    const ohLG = this.rootG.append('g').attr('class', 'open-hole-label').style('opacity', 0);
    ohLG.append('line').attr('class', 'oh-label-line')
      .attr('x1', centerX - ohHW).attr('x2', centerX - ohHW - 28)
      .attr('y1', ohLY).attr('y2', ohLY);
    ohLG.append('path').attr('class', 'oh-label-arrow')
      .attr('d', `M${centerX - ohHW - 28} ${ohLY - 5} L${centerX - ohHW - 36} ${ohLY} L${centerX - ohHW - 28} ${ohLY + 5} Z`);
    ohLG.append('text').attr('class', 'open-hole-text')
      .attr('x', centerX - ohHW - 40).attr('y', ohLY + 4)
      .attr('text-anchor', 'end')
      .text('8 1/2" Open Hole');

    let screenLabel = '';
    if (liner && liner.csgRemarks) {
      screenLabel = liner.csgRemarks;
    } else {
      const screenLen = liner ? (liner.csgDepth - deepestSolid.csgDepth) : (data.totalDepth - deepestSolid.csgDepth);
      screenLabel = `+/- ${screenLen.toLocaleString()} ft of Screen`;
    }

    const scrLG = this.rootG.append('g').attr('class', 'screen-label').style('opacity', 0);
    scrLG.append('line').attr('class', 'screen-label-line')
      .attr('x1', centerX + screenHW).attr('x2', centerX + screenHW + 28)
      .attr('y1', screenBottomPx).attr('y2', screenBottomPx);
    scrLG.append('path')
      .attr('d', buildArrowHeadRight(centerX + screenHW + 28, screenBottomPx, 6));
    scrLG.append('text').attr('class', 'screen-label-text')
      .attr('x', centerX + screenHW + 34).attr('y', screenBottomPx + 4)
      .text(screenLabel);

    clipRect.transition().delay(ohStart).duration(ANIM.OH_DURATION).ease(easeCubicInOut)
      .attr('height', tdPx - shoePx + 20);
    ohLG.transition().delay(ohLabelStart).duration(ANIM.OVERLAY_FADE).ease(easeCubicInOut).style('opacity', 1);
    scrLG.transition().delay(ohLabelStart + ANIM.OVERLAY_FADE + ANIM.SEQ_GAP).duration(ANIM.OVERLAY_FADE).ease(easeCubicInOut).style('opacity', 1);
  }

  private drawScreenHanger(
    data: WellboreDiagramData,
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    hangerStart: number,
  ): void {
    if (!data.casings.length) return;

    const { baseHalfWidth, halfWidthIncrement } = this.layout;
    const innerHW = computeCasingHalfWidth(0, baseHalfWidth, halfWidthIncrement);
    const screenHW = innerHW - 10;

    const deepestSolid = data.casings.find(c => c.csgType !== 'Liner' && c.csgType !== 'Gravel Pack') || data.casings[0];
    const shoePx = scale(deepestSolid.csgDepth);

    const { left: hangerLeft, right: hangerRight } = buildScreenHanger(centerX, shoePx + 6, screenHW);

    const hangerG = this.rootG.append('g').attr('class', 'screen-hangers').style('opacity', 0);
    hangerG.append('path')
      .attr('class', 'screen-hanger screen-hanger--left')
      .attr('stroke', '#333').attr('stroke-width', '1')
      .attr('fill', '#333')
      .attr('d', hangerLeft);
    hangerG.append('path')
      .attr('class', 'screen-hanger screen-hanger--right')
      .attr('stroke', '#333').attr('stroke-width', '1')
      .attr('fill', '#333')
      .attr('d', hangerRight);

    hangerG.transition()
      .delay(hangerStart)
      .duration(ANIM.HANGER_DURATION)
      .ease(easeCubicInOut)
      .style('opacity', 1);
  }

  private drawDrillArrow(
    data: WellboreDiagramData,
    scale: ReturnType<typeof createDepthScale>,
    drillStart: number,
    t_casingsDone: number,
  ): void {
    // Arrow always travels to totalDepth (full scale bottom)
    const arrowHeadH = 12;  // must match the arrowhead height passed to buildDepthArrow
    const endPx = scale(data.totalDepth) - arrowHeadH;
    const arrowCx = this.layout.depthArrowX;
    const duration = t_casingsDone - drillStart;  // synced to casing draw time

    this.rootG.append('path')
      .attr('class', 'depth-arrow')
      .attr('d', buildDepthArrow(0, 0, arrowCx, 10, 12))
      .transition()
      .delay(drillStart)
      .duration(duration)
      .ease(easeCubicInOut)
      .attr('d', buildDepthArrow(0, endPx, arrowCx, 10, 12));
  }

  private drawTotalDepthLabel(
    totalDepth: number,
    centerX: number,
    drawingHeight: number,
    tdLabelStart: number,
  ): void {
    this.rootG.append('text')
      .attr('class', 'total-depth-main')
      .attr('x', centerX).attr('y', drawingHeight + 26)
      .attr('text-anchor', 'middle')
      .style('opacity', 0)
      .text(`Total Depth : ${formatDepth(totalDepth)}`)
      .transition()
      .delay(tdLabelStart)
      .duration(ANIM.OVERLAY_FADE)
      .style('opacity', 1);
  }

  private drawNotDrilledZone(
    data: WellboreDiagramData,
    centerX: number,
    scale: ReturnType<typeof createDepthScale>,
    notDrilledStart: number,
  ): void {
    if (!data.prewap) return;

    const estTargetDepth = data.prewap.estTargetDepth;
    // Undrilled = estTargetDepth - wPrsntDpth
    const currentDepth = data.currentDepth;
    const undrilledFt = estTargetDepth - currentDepth;

    // Only draw if there is undrilled section remaining
    if (undrilledFt <= 0) return;

    const { baseHalfWidth, halfWidthIncrement } = this.layout;
    const innerHW = computeCasingHalfWidth(0, baseHalfWidth, halfWidthIncrement);
    const ohHW = openHoleHalfWidth(innerHW);

    const topPx = scale(currentDepth);
    const bottomPx = scale(estTargetDepth);
    const height = bottomPx - topPx;
    const width = ohHW * 2 + 160;  // +80 units each side
    const lx = centerX - ohHW - 80;
    const midY = topPx + height / 2;

    const ndg = this.rootG.append('g')
      .attr('class', 'not-drilled-zone')
      .style('opacity', 0);

    // Dashed red rectangle
    ndg.append('rect')
      .attr('class', 'not-drilled-rect')
      .attr('x', lx)
      .attr('y', topPx)
      .attr('width', width)
      .attr('height', height)
      .attr('fill', 'rgba(255,0,0,0.06)')
      .attr('stroke', 'red')
      .attr('stroke-width', 1.5)
      .attr('stroke-dasharray', '6,4');

    // Label inside the rectangle
    ndg.append('text')
      .attr('class', 'not-drilled-label')
      .attr('x', centerX)
      .attr('y', midY - 7)
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'middle')
      .attr('fill', 'red')
      .attr('font-size', '11px')
      .attr('font-weight', '600')
      .text('Not Drilled');

    // Undrilled footage sub-label
    ndg.append('text')
      .attr('class', 'not-drilled-footage')
      .attr('x', centerX)
      .attr('y', midY + 8)
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'middle')
      .attr('fill', 'red')
      .attr('font-size', '10px')
      .text(`${undrilledFt.toLocaleString()} ft remaining`);

    ndg.transition()
      .delay(notDrilledStart)
      .duration(ANIM.OVERLAY_FADE)
      .ease(easeCubicInOut)
      .style('opacity', 1);
  }
}